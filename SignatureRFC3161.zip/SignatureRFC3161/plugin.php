<?php
$id                = 'SignatureRFC3161';
$version           = '0.0.5';
$ilias_min_version = '4.4.0';
$ilias_max_version = '4.4.999';
$responsible       = 'Yves Annanias';
$responsible_mail  = 'yves.annanias@llz.uni-halle.de';
